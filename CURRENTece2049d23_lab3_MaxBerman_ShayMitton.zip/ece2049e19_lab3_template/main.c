/************** ECE2049 DEMO CODE TEMPLATE FROM 2018******************/
/*********************** 4 APRIL 2022   ******************************/
/*********************************************************************/

#include <msp430.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "peripherals.h"
#include "utils/test_runner.h"
#include "console.h"
#include "utils/ustdlib.h"

// Declare globals here
unsigned char currKey=0;
int count = 0;
int i = 0;

// TIMER FUNCTIONS
void startingA2Timer(void);
void stoppingA2Timer(void);
void timerA2Function();
void displayingA2Timer(unsigned long curr_time);
volatile unsigned long timer = 0;
volatile unsigned long counter;
unsigned long elapsed_time;
unsigned long start_time = 0;;
unsigned long current_time;
int min;
int sec;
int total_dec;
int total_sec;
char timer_on;
int second;
int secondResetCounter;
int secondMod;
int secondResetMod;
int minute;
int minuteMod;
int hour;
int hourMod;
int day;
int dayMod;
int month;
int monthMod;
int secInMonth;
int leapCount=0;
int monthIndex;
int dayIndex;
char *monthCurrent[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "AUG", "SEP", "OCT", "NOV", "DEC"};
char *dayCurrent[] = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28", "29", "30", "31"};
unsigned char strDATE[9];
unsigned char strTIME[9];
unsigned char strTEMPC[9];
unsigned char strTEMPF[9];
float tempCTotal = 0;
float tempFTotal = 0;
float tempCAverage = 0;
float tempFAverage = 0;


// TEMPERATURE FUNCTIONS
void swDelay(char numLoops1);
void swDelay2(char numLoops);
int ledDecimal(int binaryInput);
void displayTime(long unsigned int inTime);

#define CALADC12_15V_30C  *((unsigned int *)0x1A1A)
#define CALADC12_15V_85C  *((unsigned int *)0x1A1C)
#define MA_PER_BIT 0.244  // =1.0A/4096
#define CALADC12_25V_30C  *((unsigned int *)0x1A22)
#define CALADC12_25V_85C  *((unsigned int *)0x1A24)

void displayTemp(float inAvgTempC, float inAvgTempF, long unsigned int inTime);
void displayOnLCD(unsigned char monthDay[9],  unsigned char hourMinSec[9],  unsigned char tempCAverage[9],  unsigned char tempFAverage[9], long unsigned int inTime);
void tempExample(long unsigned int inTime);
void ftoa(float n, char* res, int afterpoint);

char strC[9];
char strF[9];
unsigned int   in_current,in_temp;
float  milliamps, tempC, tempF;
float arrayIndex = 1;




#pragma vector=TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR(void)
{
    if(leapCount <1024){ // can go until error cycle reached
        timer++;
        leapCount++;
    } else {            // do the leap count to correct for error
        timer+=2;
        leapCount = 0;
    }

    if ((timer % 50) == 0) { // blinking LED
        P1OUT ^= BIT0;
    }

}


enum GAME_STATE {DISPLAY, EDIT}; // display displays and edit for scroll wheel


// Main
void main(void) {

     WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                  // You can then configure it properly, if desired

     // Useful code starts here
     initLeds();
     configDisplay();
     configKeypad();

     // Configure LED P1.0 FOR TIMER
     P1SEL &= ~BIT0;
     P1DIR |= BIT0;
     startingA2Timer();
     _enable_interrupts(); // Enables global interrupts

     enum GAME_STATE state = DISPLAY;


     // for temp
     REFCTL0 &= ~REFMSTR;
     ADC12CTL0=ADC12SHT0_9|ADC12REFON|ADC12REF2_5V|ADC12ON|ADC12MSC;
     ADC12CTL1 = ADC12SHP+ADC12CONSEQ_1;
     ADC12MCTL0 = ADC12SREF_1 + ADC12INCH_0;
     ADC12MCTL1 = ADC12SREF_1 + ADC12INCH_10 + ADC12EOS;
     P6SEL = P6SEL | BIT0;





     while (1) {

         currKey = getKey(); // Get a character from the keypad
         current_time = timer; // for global A2 Timer
         elapsed_time = current_time - start_time;

         if(currKey == '1'){
             Graphics_flushBuffer(&g_sContext);
             state = EDIT;
         }
         if(currKey == '2'){
             Graphics_flushBuffer(&g_sContext);
             state = DISPLAY;
         }

         switch (state) {

                 case DISPLAY:
                     displayTime(timer); // my function always pulling current time
                     Graphics_flushBuffer(&g_sContext);
                     tempExample(timer);
                     displayTemp(tempC, tempF, timer);

                 break;

                 case EDIT:

                 break;

             } // end of states


     } // end of while(1)

}



// FUNCTIONS START HERE


void swDelay(char numLoops1)
{

	volatile unsigned int i,j;	// volatile to prevent removal in optimization
			                    // by compiler. Functionally this is useless code

	for (j=0; j<numLoops1; j++)
    {
    	i = 50000 ;					// SW Delay
   	    while (i > 0)				// could also have used while (i)
	       i--;
    }
}



void swDelay2(char numLoops)
{
    volatile unsigned int i,j;  // volatile to prevent removal in optimization
                                // by compiler. Functionally this is useless code
    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;                 // SW Delay
        while (i > 0)               // could also have used while (i)
           i--;
    }
}

int ledDecimal(int binaryInput){
    if (binaryInput == 1) {
        return 8;
    }
    if (binaryInput == 2){
        return 4;
    }
    if (binaryInput == 3){
        return 2;
    }
    if (binaryInput == 4){
        return 1;
    } return 0;
}

// A2 TIMER FUNCTIONS

void startingA2Timer(void){
    TA2CTL = TASSEL_1 | ID_0 | MC_1; // ACLK, Divide by 1, Up mode
    TA2CCR0 = 327;                   // 327 + 1 ACLK ticks = 0.01s
    TA2CCTL0 = CCIE;                 // Enable capture/compare interrupt
}
void stoppingA2Timer(void){
    TA2CTL = MC_0;     // Stop mode
    TA2CCTL0 &= ~CCIE; // Disable interrupts
}


void timerA2Function(){
    timer_on = 0; // for A2 timer
    start_time = 0; // for A2 timer
    currKey = getKey();
    if (currKey == '1') {
        timer_on = 1;
        start_time = timer; // Record timer value at start
    }
    if (currKey == '2') {
        timer_on = 0;
    }
    if (timer_on) {
        current_time = timer;
        elapsed_time = current_time - start_time;
        if ((timer % 10) == 0) {
            //displayingA2Timer(elapsed_time);
            Graphics_flushBuffer(&g_sContext);
        }
    }
}


void displayTime(long unsigned int inTime){ // needs to be always running in main while(1) loop
    // pass in global timer variable for parameter

    month = inTime/(157680000);
    monthMod = month % 12;
    day = inTime/(5184000);
    dayMod = day % 30;
    hour = inTime/(216000);
    hourMod = hour % 24;
    minute = inTime/(6000);
    minuteMod = minute % 60;
    second  = inTime/100;
    secondMod = second % 60;
    count = secondMod % 11;

    usnprintf(strDATE, 9, " %s %s   ", monthCurrent[monthMod], dayCurrent[dayMod]);
    usnprintf(strTIME, 9, "%02d:%02d:%02d", hourMod, minuteMod, secondMod);


    if ((count>=0) && (count <=2)){
        Graphics_flushBuffer(&g_sContext);
        Graphics_drawStringCentered(&g_sContext, strDATE, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    if ((count>=3) && (count <=5)) {
        Graphics_flushBuffer(&g_sContext);
        Graphics_drawStringCentered(&g_sContext, strTIME, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }

    printf("month %d, day %d, hour %d, minute %d, second %d, count %d\n", monthMod, dayMod, hourMod, minuteMod, secondMod, count);

}

void tempExample(long unsigned int inTime) {
    ADC12CTL0   &= ~ ADC12SC ;
    ADC12CTL0   |= ADC12SC + ADC12ENC;
    while (ADC12CTL1 & ADC12BUSY)   // poll busy    bit
        //__no_operation();
    in_current = ADC12MEM0 & 0x0FFF;    // keep only low 12 bits
    in_temp = ADC12MEM1 & 0x0FFF;   // keep only low 12 bits
    milliamps = (float)in_current * MA_PER_BIT;
    tempC = (float)(((long)in_temp  - CALADC12_25V_30C)*    (85  - 30))/(CALADC12_25V_85C   - CALADC12_25V_30C) + 30.0;
    tempF = (tempC * 9/5)+32;
    //printf("%f C\n", tempC);
    //printf("%f F\n", tempF);


    /*sprintf(strC, "%f C", tempC);//make the number into string using sprintf function
    sprintf(strF, "%f F", tempF);//make the number into string using sprintf function


    usnprintf(strTEMPC, 9, "%s C", strC);
    usnprintf(strTEMPF, 9, "%s F", strF);

    // for display purposes
    second  = inTime/100;
    secondMod = second % 60;
    count = secondMod % 11;

    if ((count>=6) && (count <=8)){
        Graphics_flushBuffer(&g_sContext);
        Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    if ((count>=9) && (count <=11)) {
        Graphics_flushBuffer(&g_sContext);
        Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }*/

}














void displayTemp(float inAvgTempC, float inAvgTempF, long unsigned int inTime){

    // actual averages done in another function, hence why they are parameter values
    // get average for tempC
    tempCTotal = inAvgTempC + tempCTotal; // make sure tempC and tempF Totals set to 0 globally initially
    tempFTotal = inAvgTempF + tempFTotal;
    // get average for tempF
    tempCAverage = tempCTotal / arrayIndex; // used as tempC parameter for displayOnLCD
    tempFAverage = tempFTotal / arrayIndex; // used as tempF parameter for displayOnLCD
    arrayIndex++; // have to divide by one more each time

    sprintf(strC, "%.1f", tempCAverage);//make the number into string using sprintf function
    sprintf(strF, "%.1f", tempFAverage);//make the number into string using sprintf function

    usnprintf(strTEMPC, 9, " %s C ", strC);
    usnprintf(strTEMPF, 9, " %s F  ", strF);

    // for display purposes
    second  = inTime/100;
    secondMod = second % 60;
    count = secondMod % 11;

    if ((count>=6) && (count <=8)){
        Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    if ((count>=9) && (count <=11)) {
        Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }

}







