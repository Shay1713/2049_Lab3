/************** ECE2049 DEMO CODE TEMPLATE FROM 2018******************/
/*********************** 4 APRIL 2022   ******************************/
/*********************************************************************/

#include <msp430.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "peripherals.h"
#include "utils/test_runner.h"
#include "console.h"
#include "utils/ustdlib.h"



// Declare globals here
unsigned char currKey=0;
int arrayIndex = 0;
int count = 0;
int i = 0;

// TIMER FUNCTIONS
void startingA2Timer(void);
void stoppingA2Timer(void);
void displayingA2Timer(unsigned long curr_time);
void timerA2Function();
volatile unsigned long timer = 0;
volatile unsigned long counter;
unsigned long elapsed_time;
unsigned long start_time = 0;;
unsigned long current_time;
int min;
int sec;
int total_dec;
int total_sec;
char timer_on;
int second;
int secondResetCounter;
int secondMod;
int secondResetMod;
char secondChar[2];
int minute;
int minuteMod;
char minuteChar[2];
int hour;
int hourMod;
char hourChar[2];
int day;
int dayMod;
char dayChar[2];
int month;
int monthMod;
char monthChar[3];
char whatDay[3];
char whatMonth[3];
int secInMonth;
int leapCount=0;
int monthIndex;
int dayIndex;
char *monthCurrent[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "AUG", "SEP", "OCT", "NOV", "DEC"};
char *dayCurrent[] = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28", "29", "30", "31"};
unsigned char strDATE[9];
unsigned char strTIME[9];
unsigned char strTEMPC[9];
unsigned char strTEMPF[9];
float tempCTotal = 0;
float tempFTotal = 0;
float tempCAverage = 0;
float tempFAverage = 0;

// Functions
void swDelay(char numLoops1);
void swDelay2(char numLoops);
int ledDecimal(int binaryInput);
void displayTime(long unsigned int inTime);
void displayTemp(float inAvgTempC, float inAvgTempF);
void displayOnLCD( char monthDay,  char hourMinSec,  char tempCAverage,  char tempFAverage, long unsigned int inTimer);



#pragma vector=TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR(void)
{
    if(leapCount <1024){ // can go until error cycle reached
        timer++;
        leapCount++;
    } else {            // do the leap count to correct for error
        timer+=2;
        leapCount = 0;
    }

    if ((timer % 50) == 0) { // blinking LED
        P1OUT ^= BIT0;
    }

}




// Main
void main(void) {

     WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                  // You can then configure it properly, if desired

     // Useful code starts here
     initLeds();
     configDisplay();
     configKeypad();

     // Configure LED P1.0 FOR TIMER
     P1SEL &= ~BIT0;
     P1DIR |= BIT0;
     startingA2Timer();
     _enable_interrupts(); // Enables global interrupts


     while (1) {
         currKey = getKey(); // Get a character from the keypad
         displayTime(timer); // my function always pulling current time


         current_time = timer; // for global A2 Timer
         elapsed_time = current_time - start_time;





     } // end of while(1)

}



// FUNCTIONS START HERE


void swDelay(char numLoops1)
{
	// This function is a software delay. It performs
	// useless loops to waste a bit of time
	//
	// Input: numLoops = number of delay loops to execute
	// Output: none
	//
	// smj, ECE2049, 25 Aug 2013

	volatile unsigned int i,j;	// volatile to prevent removal in optimization
			                    // by compiler. Functionally this is useless code

	for (j=0; j<numLoops1; j++)
    {
    	i = 50000 ;					// SW Delay
   	    while (i > 0)				// could also have used while (i)
	       i--;
    }
}



void swDelay2(char numLoops)
{
    volatile unsigned int i,j;  // volatile to prevent removal in optimization
                                // by compiler. Functionally this is useless code
    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;                 // SW Delay
        while (i > 0)               // could also have used while (i)
           i--;
    }
}

int ledDecimal(int binaryInput){
    if (binaryInput == 1) {
        return 8;
    }
    if (binaryInput == 2){
        return 4;
    }
    if (binaryInput == 3){
        return 2;
    }
    if (binaryInput == 4){
        return 1;
    } return 0;
}

// A2 TIMER FUNCTIONS

void startingA2Timer(void){
    TA2CTL = TASSEL_1 | ID_0 | MC_1; // ACLK, Divide by 1, Up mode
    TA2CCR0 = 327;                   // 327 + 1 ACLK ticks = 0.01s
    TA2CCTL0 = CCIE;                 // Enable capture/compare interrupt
}
void stoppingA2Timer(void){
    TA2CTL = MC_0;     // Stop mode
    TA2CCTL0 &= ~CCIE; // Disable interrupts
}

/*void displayingA2Timer(unsigned long curr_time){ // use displayTime(long unsigned int inTime) function for lab 3 instead
    // First, get each portion of the display using integer math
    total_sec =  curr_time / 100; // Seconds (integer part)
    total_dec = curr_time % 100; // Hundredths (fractional part)
    min = total_sec / 60; // Minutes
    sec = total_sec % 60; // Seconds
    //unsigned char str[9]; // mm:ss.hh = 8 chars + null terminator
    //printf(str, 9, "%02d:%02d.%02d", min, sec, total_dec);
    printf("minutes %d seconds %d total_dec %d\n", min, sec, total_dec);
    //Graphics_drawStringCentered(&g_sContext, str, 9, 48, 15, OPAQUE_TEXT);
}*/

void timerA2Function(){
    timer_on = 0; // for A2 timer
    start_time = 0; // for A2 timer
    currKey = getKey();
    if (currKey == '1') {
        timer_on = 1;
        start_time = timer; // Record timer value at start
    }
    if (currKey == '2') {
        timer_on = 0;
    }
    if (timer_on) {
        current_time = timer;
        elapsed_time = current_time - start_time;
        if ((timer % 10) == 0) {
            displayingA2Timer(elapsed_time);
            Graphics_flushBuffer(&g_sContext);
        }
    }
}


void displayTime(long unsigned int inTime){ // needs to be always running in main while(1) loop
    // pass in global timer variable for parameter

    month = inTime/(157680000);
    monthMod = month % 12;
    day = inTime/(5184000);
    dayMod = day % 30;
    hour = inTime/(216000);
    hourMod = hour % 24;
    minute = inTime/(6000);
    minuteMod = minute % 60;
    second  = inTime/100;
    secondMod = second % 60;
    count = secondMod % 11;

    usnprintf(strDATE, 9, "%s %s", monthCurrent[monthMod], dayCurrent[dayMod]);
    usnprintf(strTIME, 9, "%02d:%02d:%02d", hourMod, minuteMod, secondMod);


    if ((count>=0) && (count <=2)){
        Graphics_drawStringCentered(&g_sContext, strDATE, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    if ((count>=3) && (count <=5)) {
        Graphics_drawStringCentered(&g_sContext, strTIME, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    if((count>=6) && (count <=11)) {
        Graphics_clearDisplay(&g_sContext);
        Graphics_flushBuffer(&g_sContext);
    }




    /*// works to always display
    usnprintf(strDATE, 9, "%s %s", monthCurrent[monthMod], dayCurrent[dayMod]);
    Graphics_drawStringCentered(&g_sContext, strDATE, 9, 48, 15, OPAQUE_TEXT);
    Graphics_flushBuffer(&g_sContext);

    usnprintf(strTIME, 9, "%02d:%02d:%02d", hourMod, minuteMod, secondMod); // works as of 9:10am 4/12/23
    Graphics_drawStringCentered(&g_sContext, strTIME, 9, 48, 25, OPAQUE_TEXT);
    Graphics_flushBuffer(&g_sContext);*/

    printf("month %d, day %d, hour %d, minute %d, second %d, count %d\n", monthMod, dayMod, hourMod, minuteMod, secondMod, count);

}







/*void displayTemp(float inAvgTempC, float inAvgTempF){
    // get average for tempC
    tempCTotal = inAvgTempC + tempCTotal;
    tempFTotal = inAvgTempF + tempFTotal;
    // get average for tempF
    tempCAverage = tempCTotal / arrayIndex; // used as tempC parameter for displayOnLCD
    tempFAverage = tempFTotal / arrayIndex; // used as tempF parameter for displayOnLCD
    arrayIndex++;

    usnprintf(strTEMPC, 9, "%03d.%0.1d C\n", tempC, tempCfrac); // working on
    Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
    Graphics_flushBuffer(&g_sContext);

    usnprintf(strTEMPF, 9, "%03d.%0.1d F\n", tempF, tempFfrac);
    Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
    Graphics_flushBuffer(&g_sContext);
}*/

/*void displayOnLCD( char monthDay,  char hourMinSec,  char tempCAverage,  char tempFAverage, long unsigned int inTimer){ // parameter str

    secondResetCounter = (inTimer/(60)) % 60;

    if (secondResetCounter == (0 | 1 | 2 | 12 | 13 | 14 | 24 | 25 | 26 | 36 | 37 | 38 | 48 | 49 | 50)){
        Graphics_drawStringCentered(&g_sContext, monthDay, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    } else if (secondResetCounter == (3 | 4 | 5 | 15 | 16 | 17 | 27 | 28 | 29 | 39 | 40 | 41 | 51 | 52 | 53)) {
        Graphics_drawStringCentered(&g_sContext, hourMinSec, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    } else if (secondResetCounter == (6 | 7 | 8 | 18 | 19 | 20 | 30 | 31 | 32 | 42 | 43 | 44 | 54 | 55 | 56)) {
        Graphics_drawStringCentered(&g_sContext, tempCAverage, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    } else if (secondResetCounter == (9 | 10 | 11 | 21 | 22 | 23 | 33 | 34 | 35 | 45 | 46 | 47 | 57 | 58 | 59)) {
        Graphics_drawStringCentered(&g_sContext, tempFAverage, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
}*/






