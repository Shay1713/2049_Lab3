/************** ECE2049 DEMO CODE TEMPLATE FROM 2018******************/
/*********************** 4 APRIL 2022   ******************************/
/*********************************************************************/

#include <msp430.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "peripherals.h"
#include "utils/test_runner.h"
#include "console.h"
#include "utils/ustdlib.h"

// Declare globals here
unsigned char currKey=0;
unsigned char valueKey=0;
int count = 0;
int counterMOD = 0;
int i = 0;
int newCounter;

// TIMER FUNCTIONS
void startingA2Timer(void);
void stoppingA2Timer(void);
void timerA2Function();
void displayingA2Timer(unsigned long curr_time);
volatile unsigned long timer = 0;
volatile unsigned long counter;
unsigned long elapsed_time;
unsigned long start_time = 0;;
unsigned long current_time;
int min;
int sec;
int total_dec;
int total_sec;
char timer_on;
int second;
int secondResetCounter;
int secondMod;
int secondResetMod;
int minute;
int minuteMod;
int hour;
int hourMod;
int day;
int dayMod;
int month;
int monthMod;
int secInMonth;
int leapCount=0;
int monthIndex;
int dayIndex;
char *monthCurrent[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "AUG", "SEP", "OCT", "NOV", "DEC"};
char *dayCurrent[] = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28", "29", "30", "31"};
unsigned char strDATE[9];
unsigned char strTIME[9];
float tempCTotal = 0;
float tempFTotal = 0;
float tempCAverage = 0;
float tempFAverage = 0;


// TEMPERATURE FUNCTIONS
void swDelay(char numLoops1);
void swDelay2(char numLoops);
int ledDecimal(int binaryInput);
void displayTime(long unsigned int inTime);

#define CALADC12_15V_30C  *((unsigned int *)0x1A1A)
#define CALADC12_15V_85C  *((unsigned int *)0x1A1C)
#define MA_PER_BIT 0.244  // =1.0A/4096
#define CALADC12_25V_30C  *((unsigned int *)0x1A22)
#define CALADC12_25V_85C  *((unsigned int *)0x1A24)

void displayTemp(float inAvgTempC, float inAvgTempF, long unsigned int inTime);
void displayOnLCD(unsigned char monthDay[9],  unsigned char hourMinSec[9],  unsigned char tempCAverage[9],  unsigned char tempFAverage[9], long unsigned int inTime);
void tempExample(long unsigned int inTime);
void ftoa(float n, char* res, int afterpoint);

char strC[35];
char strF[35];
int modulo30;
unsigned char strTEMPC[35];
unsigned char strTEMPF[35];
unsigned int   in_current,in_temp;
float  milliamps, tempC, tempF;
float arrayIndex = 1;
unsigned int inValue = 0;



#pragma vector=TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR(void)
{
    if(leapCount <1024){ // can go until error cycle reached
        timer++;
        leapCount++;
    } else {            // do the leap count to correct for error
        timer+=2;
        leapCount = 0;
    }

    if ((timer % 50) == 0) { // blinking LED
        P1OUT ^= BIT0;
    }

}


enum GAME_STATE {DISPLAY, EDITmonth, EDITday, EDIThour, EDITminute, EDITsecond}; // display displays and edit for scroll wheel


// Main
void main(void) {

     WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                  // You can then configure it properly, if desired

     // Useful code starts here
     initLeds();
     configDisplay();
     configKeypad();

     // Configure LED P1.0 FOR TIMER
     P1SEL &= ~BIT0;
     P1DIR |= BIT0;
     startingA2Timer();
     _enable_interrupts(); // Enables global interrupts

     enum GAME_STATE state = DISPLAY;


     // for temp
     REFCTL0 &= ~REFMSTR;
     ADC12CTL0=ADC12SHT0_9|ADC12REFON|ADC12REF2_5V|ADC12ON|ADC12MSC;
     ADC12CTL1 = ADC12SHP+ADC12CONSEQ_1;
     ADC12MCTL0 = ADC12SREF_1 + ADC12INCH_0;
     ADC12MCTL1 = ADC12SREF_1 + ADC12INCH_10 + ADC12EOS;
     P6SEL = P6SEL | BIT0;

     while (1) {

         currKey = getKey(); // Get a character from the keypad
         current_time = timer; // for global A2 Timer
         elapsed_time = current_time - start_time;


         switch (state) {

                 case DISPLAY:
                     displayTime(timer); // my function always pulling current time
                     Graphics_flushBuffer(&g_sContext);
                     tempExample(timer);
                     displayTemp(tempC, tempF, timer);

                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITmonth;
                     }

                 break;

                 case EDITmonth:



                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITday;
                     }
                     if(currKey == '2'){
                         Graphics_flushBuffer(&g_sContext);
                         state = DISPLAY;
                     }

                 break;

                 case EDITday:



                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDIThour;
                     }
                     if(currKey == '2'){
                         Graphics_flushBuffer(&g_sContext);
                         state = DISPLAY;
                     }

                 break;

                 case EDIThour:


                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITminute;
                     }
                     if(currKey == '2'){
                         Graphics_flushBuffer(&g_sContext);
                         state = DISPLAY;
                     }

                 break;


                 case EDITminute:


                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITsecond;
                     }
                      if(currKey == '2'){
                          Graphics_flushBuffer(&g_sContext);
                          state = DISPLAY;
                      }

                  break;

                 case EDITsecond:


                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITmonth;
                     }
                      if(currKey == '2'){
                          Graphics_flushBuffer(&g_sContext);
                          state = DISPLAY;
                      }

                  break;



             } // end of states


     } // end of while(1)

}



// FUNCTIONS START HERE


void swDelay(char numLoops1)
{

	volatile unsigned int i,j;	// volatile to prevent removal in optimization
			                    // by compiler. Functionally this is useless code

	for (j=0; j<numLoops1; j++)
    {
    	i = 50000 ;					// SW Delay
   	    while (i > 0)				// could also have used while (i)
	       i--;
    }
}



void swDelay2(char numLoops)
{
    volatile unsigned int i,j;  // volatile to prevent removal in optimization
                                // by compiler. Functionally this is useless code
    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;                 // SW Delay
        while (i > 0)               // could also have used while (i)
           i--;
    }
}

int ledDecimal(int binaryInput){
    if (binaryInput == 1) {
        return 8;
    }
    if (binaryInput == 2){
        return 4;
    }
    if (binaryInput == 3){
        return 2;
    }
    if (binaryInput == 4){
        return 1;
    } return 0;
}

// A2 TIMER FUNCTIONS

void startingA2Timer(void){
    TA2CTL = TASSEL_1 | ID_0 | MC_1; // ACLK, Divide by 1, Up mode
    TA2CCR0 = 327;                   // 327 + 1 ACLK ticks = 0.01s
    TA2CCTL0 = CCIE;                 // Enable capture/compare interrupt
}
void stoppingA2Timer(void){
    TA2CTL = MC_0;     // Stop mode
    TA2CCTL0 &= ~CCIE; // Disable interrupts
}


void timerA2Function(){
    timer_on = 0; // for A2 timer
    start_time = 0; // for A2 timer
    currKey = getKey();
    if (currKey == '1') {
        timer_on = 1;
        start_time = timer; // Record timer value at start
    }
    if (currKey == '2') {
        timer_on = 0;
    }
    if (timer_on) {
        current_time = timer;
        elapsed_time = current_time - start_time;
        if ((timer % 10) == 0) {
            //displayingA2Timer(elapsed_time);
            Graphics_flushBuffer(&g_sContext);
        }
    }
}


void displayTime(long unsigned int inTime){ // needs to be always running in main while(1) loop
    // pass in global timer variable for parameter

    month = inTime/(157680000);
    monthMod = month % 12;
    day = inTime/(5184000);
    dayMod = day % 30;
    hour = inTime/(216000);
    hourMod = hour % 24;
    minute = inTime/(6000);
    minuteMod = minute % 60;
    second  = inTime/100;
    secondMod = second % 60;
    count = secondMod % 12;

    usnprintf(strDATE, 9, " %s %s   ", monthCurrent[monthMod], dayCurrent[dayMod]);
    usnprintf(strTIME, 9, "%02d:%02d:%02d", hourMod, minuteMod, secondMod);


    if ((count>=0) && (count <=2)){
        Graphics_flushBuffer(&g_sContext);
        Graphics_drawStringCentered(&g_sContext, strDATE, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    if ((count>=3) && (count <=5)) {
        Graphics_flushBuffer(&g_sContext);
        Graphics_drawStringCentered(&g_sContext, strTIME, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }

    printf("month %d, day %d, hour %d, minute %d, second %d, count %d\n", monthMod, dayMod, hourMod, minuteMod, secondMod, count);

}

void tempExample(long unsigned int inTime) {
    ADC12CTL0   &= ~ ADC12SC ;
    ADC12CTL0   |= ADC12SC + ADC12ENC;
    while (ADC12CTL1 & ADC12BUSY)   // poll busy    bit
        //__no_operation();
    in_current = ADC12MEM0 & 0x0FFF;    // keep only low 12 bits
    in_temp = ADC12MEM1 & 0x0FFF;   // keep only low 12 bits
    milliamps = (float)in_current * MA_PER_BIT;
    tempC = (float)(((long)in_temp  - CALADC12_25V_30C)*    (85  - 30))/(CALADC12_25V_85C   - CALADC12_25V_30C) + 30.0;
    tempF = (tempC * 9/5)+32;
    //printf("%f C\n", tempC);
    //printf("%f F\n", tempF);

}

void displayTemp(float inAvgTempC, float inAvgTempF, long unsigned int inTime){


    // for display purposes
    second  = inTime/100;
    secondMod = second % 60;
    count = secondMod % 12;

    newCounter = secondMod % 35; // holding thirty five indexes

    if((count>=6) && (count<7) ){
        if(counterMOD == 0){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            /*if(arrayIndex < 35){
                arrayIndex++; // until the array has thirty full values
            } else if (arrayIndex == 35){
                arrayIndex = 35; // once the array is full
            }*/
            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 1;
        }
    }
    if((count>=7) && (count<8) ){
        if(counterMOD == 1){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            /*if(arrayIndex < 35){
                arrayIndex++; // until the array has thirty full values
            } else if (arrayIndex == 35){
                arrayIndex = 35; // once the array is full
            }*/
            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);

            counterMOD = 2;
        }
    }
    if((count>=8) && (count<9) ){
        if(counterMOD == 2){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            /*if(arrayIndex < 35){
                arrayIndex++; // until the array has thirty full values
            } else if (arrayIndex == 35){
                arrayIndex = 35; // once the array is full
            }*/
            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 3;
        }
    }
    if((count>=9) && (count<10) ){
        if(counterMOD == 3){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            /*if(arrayIndex < 35){
                arrayIndex++; // until the array has thirty full values
            } else if (arrayIndex == 35){
                arrayIndex = 35; // once the array is full
            }*/
            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 4;
        }
    }
    if((count>=10) && (count<11) ){
        if(counterMOD == 4){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            /*if(arrayIndex < 35){
                arrayIndex++; // until the array has thirty full values
            } else if (arrayIndex == 35){
                arrayIndex = 35; // once the array is full
            }*/
            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 5;
        }
    }
    if((count>=11) && (count<12) ){
        if(counterMOD == 5){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            /*if(arrayIndex < 35){
                arrayIndex++; // until the array has thirty full values
            } else if (arrayIndex == 35){
                arrayIndex = 35; // once the array is full
            }*/
            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 0;
        }
}




    /*if ((count>=6) && (count <=8)){
        Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    if ((count>=9) && (count <=11)) {
        Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }*/

}





