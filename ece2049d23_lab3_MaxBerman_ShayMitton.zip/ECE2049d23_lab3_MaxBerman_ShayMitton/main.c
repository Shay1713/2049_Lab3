/************** ECE 2049 LAB 2 ******************/
/**************  4 APRIL 2023   ******************/


#include <msp430.h>
#include "peripherals.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


// Declare globals here
unsigned char currKey=0;
int arrayIndex = 0;
int count = 0;
int i = 0;

// Functions
void swDelay2(char numLoops);
int ledDecimal(int binaryInput);



// TIMER FUNCTIONS
void startingA2Timer(void);
void stoppingA2Timer(void);
void displayingA2Timer(unsigned long curr_time);
void timerA2Function();
volatile unsigned long timer = 0;
volatile unsigned long counter;
unsigned long elapsed_time;
unsigned long start_time = 0;;
unsigned long current_time;
int min;
int sec;
int total_dec;
int total_sec;
char timer_on;
int second;
char secondChar[2];
int minute;
char minuteChar[2];
int hour;
char hourChar[2];
int day;
char dayChar[2];
int month;
char monthChar[3];
char whatDay[3];
char whatMonth[3];
int secInMonth;
int leapCount=0;
char *monthCurrent[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "AUG", "SEP", "OCT", "NOV", "DEC"};
char *dayCurrent[] = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28", "29", "30", "31"};
unsigned char strDATE[9];
unsigned char strTIME[9];
unsigned char strTEMPC[9];
unsigned char strTEMPF[9];
float tempCTotal = 0;
float tempFTotal = 0;
float tempCAverage = 0;
float tempFAverage = 0;


void displayTime(long unsigned int inTime);
void displayTemp(float inAvgTempC, float inAvgTempF);
void displayOnLCD(int timeMonth, int timeDay, int timeHour, int timeMinute, int timeSecond, int tempC, int tempF, int globalCounter);

#pragma vector=TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR(void)
{
    if(leapCount <1024){ // can go until error cycle reached
        timer++;
        leapCount++;
    } else {            // do the leap count to correct for error
        timer+=2;
        leapCount = 0;
    }

    if ((timer % 50) == 0) { // blinking LED
        P1OUT ^= BIT0;
    }
    counter++;
}

// TEMPERATURE FUNCTIONS

#define CALADC12_15V_30C *((unsigned int *)0x1A1A)
#define CALADC12_15V_85C *((unsigned int *)0x1A1C)

unsigned int in_temp;


// Main
void main(void)

{
    WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                     // You can then configure it properly, if desired

    // Useful code starts here
    initLeds();
    configDisplay();
    configKeypad();


    // Configure LED P1.0 FOR TIMER
    P1SEL &= ~BIT0;
    P1DIR |= BIT0;
    startingA2Timer();
    _enable_interrupts(); // Enables global interrupts


    // Configuring FOR TEMPERATURE
    volatile float temperatureDegC;
    volatile float temperatureDegF;
    volatile float degC_per_bit;
    volatile unsigned int bits30, bits85;

    REFCTL0 &= ~REFMSTR;
    ADC12CTL0 = ADC12SHT0_9 | ADC12REFON | ADC12ON;
    ADC12CTL1 = ADC12SHP;
    ADC12MCTL0 = ADC12SREF_1 + ADC12INCH_10;

    __delay_cycles(100);
    ADC12CTL0 |= ADC12ENC;

    bits30 = CALADC12_15V_30C; // Use calibration data stored in info memory
    bits85 = CALADC12_15V_85C;
    degC_per_bit = ((float)(85.0 - 30.0))/((float)(bits85-bits30));




    while (1)
    {
        currKey = getKey();


        displayTime(timer); // my function always pulling current time

        current_time = timer; // for global A2 Timer
        elapsed_time = current_time - start_time;

        ADC12CTL0 &= ~ADC12SC; // for global temperature
        ADC12CTL0 |= ADC12SC;  // Sampling and conversion start
        while (ADC12CTL1 & ADC12BUSY) // Poll busy bit waiting for conversion to complete
            __no_operation();
        in_temp = ADC12MEM0; // Read in results if conversion
        // to get board's C and F temperatures
        temperatureDegC = (float)((long)in_temp - CALADC12_15V_30C) * degC_per_bit +30.0;
        temperatureDegF =  (temperatureDegC *9/5) +32;

        displayTemp(temperatureDegC, temperatureDegF);
        displayOnLCD(month, day, hour, minute, second, tempCAverage, tempFAverage, counter);


        __no_operation(); // set breakpoint here I think ?


    }  // end while (1)
}


// FUNCTIONS START HERE


void swDelay2(char numLoops)
{
    volatile unsigned int i,j;  // volatile to prevent removal in optimization
                                // by compiler. Functionally this is useless code
    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;                 // SW Delay
        while (i > 0)               // could also have used while (i)
           i--;
    }
}

int ledDecimal(int binaryInput){
    if (binaryInput == 1) {
        return 8;
    }
    if (binaryInput == 2){
        return 4;
    }
    if (binaryInput == 3){
        return 2;
    }
    if (binaryInput == 4){
        return 1;
    } return 0;
}

// A2 TIMER FUNCTIONS

void startingA2Timer(void){
    TA2CTL = TASSEL_1 | ID_0 | MC_1; // ACLK, Divide by 1, Up mode
    TA2CCR0 = 32767;                   // 32767 + 1 ACLK ticks = 1s
    TA2CCTL0 = CCIE;                 // Enable capture/compare interrupt
}
void stoppingA2Timer(void){
    TA2CTL = MC_0;     // Stop mode
    TA2CCTL0 &= ~CCIE; // Disable interrupts
}

/*void displayingA2Timer(unsigned long curr_time){ // use displayTime(long unsigned int inTime) function for lab 3 instead
    // First, get each portion of the display using integer math
    total_sec =  curr_time / 100; // Seconds (integer part)
    total_dec = curr_time % 100; // Hundredths (fractional part)
    min = total_sec / 60; // Minutes
    sec = total_sec % 60; // Seconds
    //unsigned char str[9]; // mm:ss.hh = 8 chars + null terminator
    //printf(str, 9, "%02d:%02d.%02d", min, sec, total_dec);
    printf("minutes %d seconds %d total_dec %d\n", min, sec, total_dec);
    //Graphics_drawStringCentered(&g_sContext, str, 9, 48, 15, OPAQUE_TEXT);
}*/

void timerA2Function(){
    timer_on = 0; // for A2 timer
    start_time = 0; // for A2 timer
    currKey = getKey();
    if (currKey == '1') {
        timer_on = 1;
        start_time = timer; // Record timer value at start
    }
    if (currKey == '2') {
        timer_on = 0;
    }
    if (timer_on) {
        current_time = timer;
        elapsed_time = current_time - start_time;
        if ((timer % 10) == 0) {
            displayingA2Timer(elapsed_time);
            Graphics_flushBuffer(&g_sContext);
        }
    }
}


void displayTime(long unsigned int inTime){ // needs to be always running in main while(1) loop
    // pass in global timer variable for parameter
    // each count on the timer is currently set to a 0.1 second interval rate
    month = inTime/(2629800);
    day = inTime/(86400);
    hour = inTime/(3600);
    minute = inTime/(60);
    second  = (inTime);

    //usnprintf(strDATE, 9, "%03s:%02s\n", monthCurrent[timeMonth - 1], dayCurrent[timeDay - 1]);
    //Graphics_drawStringCentered(&g_sContext, strTIME, 9, 48, 15, OPAQUE_TEXT);
    //Graphics_flushBuffer(&g_sContext);

    //usnprintf(strDATE, 9, "%02d:%02d:%02d\n", timeHour, timeMinute, timeSecond);
    //Graphics_drawStringCentered(&g_sContext, strDATE, 9, 48, 15, OPAQUE_TEXT);
    //Graphics_flushBuffer(&g_sContext);

}

void displayTemp(float inAvgTempC, float inAvgTempF){
    // get average for tempC
    tempCTotal = inAvgTempC + tempCTotal;
    tempFTotal = inAvgTempF + tempFTotal;
    // get average for tempF
    tempCAverage = tempCTotal / arrayIndex; // used as tempC parameter for displayOnLCD
    tempFAverage = tempFTotal / arrayIndex; // used as tempF parameter for displayOnLCD
    arrayIndex++;

    //usnprintf(strTEMPC, 9, "%03d.%0.1d C\n", tempC, tempCfrac); // working on
    //Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
    //Graphics_flushBuffer(&g_sContext);

    //usnprintf(strTEMPF, 9, "%03d.%0.1d F\n", tempF, tempFfrac);
    //Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
    //Graphics_flushBuffer(&g_sContext);
}

void displayOnLCD(int timeMonth, int timeDay, int timeHour, int timeMinute, int timeSecond, int tempC, int tempF, int globalCounter) { // need to call in main while(1) still

    current_time = globalCounter;
    start_time = 0;
    elapsed_time = current_time - start_time;
    int usnprintf(unsigned char *pcBuf, unsigned long ulSize, const unsigned char *pcString, ...);

    if ((elapsed_time % (10 | 11 | 12)) == 0) // printing TEMPF string to LCD for 3 sec
    {
        usnprintf(strTEMPF, 9, "%03d.%0.1d F\n", tempF, tempF);
        Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
        if((elapsed_time/1200) == 1){
            counter = 0;
        }
    }
    else if ((elapsed_time % (7 | 8 | 9)) == 0) // printing TEMPC string to LCD for 3 sec
    {
        usnprintf(strTEMPC, 9, "%03d.%0.1d C\n", tempC, tempC); // working on
        Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    else if ((elapsed_time % (4 | 5 | 6)) == 0) // printing Date string to LCD for 3 sec
    {
        usnprintf(strDATE, 9, "%02d:%02d:%02d\n", timeHour, timeMinute, timeSecond);
        Graphics_drawStringCentered(&g_sContext, strDATE, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    else if ((elapsed_time % (1 | 2 | 3)) == 0) // printing TIME string to LCD for 3 sec
    {
        usnprintf(strDATE, 9, "%03s:%02s\n", monthCurrent[timeMonth - 1], dayCurrent[timeDay - 1]);
        Graphics_drawStringCentered(&g_sContext, strTIME, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }

}


