/*
 * peripherals.h
 *
 *  Created on: Jan 29, 2014
 *      Author:  ndemarinis
 *  Update on: 9 Jan 2019, 22 Aug 2018 -- smj
 */

#ifndef PERIPHERALS_H_
#define PERIPHERALS_H_

#include <msp430.h>
#include <stdint.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>
#include <intrinsics.h>
#include "grlib.h"

#include "LcdDriver/Sharp96x96.h"
#include "LcdDriver/HAL_MSP_EXP430FR5529_Sharp96x96.h"


/*
 * DAC pin assignment is as follows
 * LDAC         P3.7
 * CS           P8.2
 * MOSI/SDI     P3.0
 * SCLK         P3.2
 */
#define DAC_PORT_LDAC_SEL       P3SEL
#define DAC_PORT_LDAC_DIR       P3DIR
#define DAC_PORT_LDAC_OUT       P3OUT

#define DAC_PORT_CS_SEL         P8SEL
#define DAC_PORT_CS_DIR         P8DIR
#define DAC_PORT_CS_OUT         P8OUT

#define DAC_PORT_SPI_SEL        P3SEL
#define DAC_PORT_SPI_DIR        P3DIR

#define DAC_PIN_MOSI            BIT0
#define DAC_PIN_SCLK            BIT2
#define DAC_PIN_CS              BIT2
#define DAC_PIN_LDAC            BIT7

#define DAC_SPI_REG_CTL0        UCB0CTL0
#define DAC_SPI_REG_CTL1        UCB0CTL1
#define DAC_SPI_REG_BRL         UCB0BR0
#define DAC_SPI_REG_BRH         UCB0BR1
#define DAC_SPI_REG_IFG         UCB0IFG
#define DAC_SPI_REG_STAT        UCB0STAT
#define DAC_SPI_REG_TXBUF       UCB0TXBUF
#define DAC_SPI_REG_RXBUF       UCB0RXBUF

/*
 * UCSI SPI Clock parameters
 * The actual clock frequency is given in number of
 * ticks of the specified clock source.
 *
 * For our configuration, we use SMCLK */
#define DAC_SPI_CLK_SRC     (UCSSEL__SMCLK)
#define DAC_SPI_CLK_TICKS   0

// Globals
extern tContext g_sContext; // user defined type used by graphics library

// Prototypes for functions defined implemented in peripherals.c

//void DACInit(void);
//void DACSetValue(unsigned int dac_code);
//void setupSPI_DAC(void);
void initLeds(void);
void setLeds(unsigned char state);
void configDisplay(void);

void BuzzerOn(void);
void BuzzerOnControl(unsigned int sound);
void BuzzerOff(void);

void configKeypad(void);
unsigned char getKey(void);


// lab 3
unsigned char *
ustrncpy (unsigned char *pcDst, const unsigned char *pcSrc, int iNum);

int uvsnprintf(unsigned char *pcBuf, unsigned long ulSize, const unsigned char *pcString, va_list vaArgP);

int usprintf(unsigned char *pcBuf, const unsigned char *pcString, ...);

int usnprintf(unsigned char *pcBuf, unsigned long ulSize, const unsigned char *pcString, ...);

unsigned long ustrtoul(const unsigned char *pcStr, const unsigned char **ppcStrRet, int iBase);

int ustrlen(const unsigned char * pcStr);

unsigned char *
ustrstr(const unsigned char *pcHaystack, const unsigned char *pcNeedle);

int
ustrnicmp(const unsigned char *pcStr1, const unsigned char *pcStr2, int iCount);

int
ustrcasecmp(const unsigned char *pcStr1, const unsigned char *pcStr2);

int
ustrncmp(const unsigned char *pcStr1, const unsigned char *pcStr2, int iCount);

int
ustrcmp(const unsigned char *pcStr1, const unsigned char *pcStr2);

void
usrand(unsigned long ulSeed);

int
urand(void);

/*
 * Break to debugger
 * Since the debugger does not appear to halt until
 * one or more instructions after the opcode is given,
 * we add a few nop's here.
 */
#define DEBUG_BREAK() do { \
    _op_code(0x4343); \
    _no_operation(); \
    _no_operation(); \
} while (0)

//#define VERBOSE_ASSERT_MESSAGES

#ifdef VERBOSE_ASSERT_MESSAGES
#define ASSERT_FAIL(cond) do { \
    fputs("Assertion failed, (" _STR(cond) "), file " __FILE__ \
          ", line " _STR(__LINE__) "\n", stderr); \
    fflush(stderr); \
} while(0)
#else
#define ASSERT_FAIL(cond) do { \
    fputs("Assertion failed:  if you can't see enough info, " \
          "set a breakpoint here and restart to see the program state.\n", stderr); \
    fflush(stderr); \
} while(0)
#endif


// TEST_ASSERT2(actual, expected)
// Break to debugger if (actual != expected)
// In the debugger, the variables window will show variables
// _actual and _expected, indicating the values of
// each side of the expression tested.
#ifdef VERBOSE_ASSERT_MESSAGES
#define TEST_ASSERT2(actual, expected) do { \
    volatile typeof(actual) _actual = (actual); \
    volatile typeof(expected) _expected = (expected); \
    if((_actual) != (_expected)) { \
        snprintf(__actual_str,   DEBUG_STR_SIZE, "%d", _actual); \
        snprintf(__expected_str, DEBUG_STR_SIZE, "%d", _expected); \
        fputs("Assertion failed:  Received:  ", stderr); \
        fputs(__actual_str, stderr); \
        fputs(", Expected:  ", stderr); \
        fputs(__expected_str, stderr); \
        fputs("\n", stderr); \
        fflush(stderr); \
        DEBUG_BREAK(); \
    } \
} while(0)
#else
#define TEST_ASSERT2(actual, expected) do { \
    volatile typeof(actual) _actual = (actual); \
    volatile typeof(expected) _expected = (expected); \
    if((_actual) != (_expected)) { \
        fputs("Assertion failed:  See Variables.  If you can't see enough info, " \
              "set a breakpoint here and restart to see the program state.\n", stderr); \
        fflush(stderr); \
        DEBUG_BREAK(); \
    } \
} while(0)
#endif


/*
 * TEST_ASSERT(cond)
 * Break to debugger is (cond) is false
 */
#define TEST_ASSERT(cond) do { \
    if(!(cond)) { \
        ASSERT_FAIL((cond)); \
        DEBUG_BREAK(); \
    } \
} while (0)

#define ASSERT(cond) TEST_ASSERT(cond)


#endif /* PERIPHERALS_H_ */
