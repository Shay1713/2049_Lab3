/************** ECE2049 DEMO CODE TEMPLATE FROM 2018******************/
/*********************** 4 APRIL 2022   ******************************/
/*********************************************************************/

#include <msp430.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "peripherals.h"
#include "utils/test_runner.h"
#include "console.h"
#include "utils/ustdlib.h"

// Declare globals here
unsigned char currKey=0;
unsigned char valueKey=0;
int count = 0;
int counterMOD = 0;
int i = 0;
int newCounter;

// TIMER FUNCTIONS
void startingA2Timer(void);
void stoppingA2Timer(void);
void timerA2Function();
void displayingA2Timer(unsigned long curr_time);
volatile unsigned long timer = 0;
volatile unsigned long counter;
unsigned long elapsed_time;
unsigned long start_time = 0;;
unsigned long current_time;
unsigned long int min;
unsigned long int sec;
unsigned long int total_dec;
unsigned long int total_sec;
char timer_on;
unsigned long int second;
int secondResetCounter;
int secondMod;
int secondResetMod;
unsigned long int minute;
int minuteMod;
unsigned long int hour;
int hourMod;
unsigned long int day;
int dayMod;
unsigned long int month;
int monthMod;
unsigned long int secInMonth;
int leapCount=0;
unsigned long int monthIndex;
unsigned long int dayIndex;
char *monthCurrent[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "AUG", "SEP", "OCT", "NOV", "DEC"};
char *dayCurrent[] = {"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22","23", "24", "25", "26", "27", "28", "29", "30", "31"};
unsigned char strDATE[9];
unsigned char strTIME[9];
float tempCTotal = 0;
float tempFTotal = 0;
float tempCAverage = 0;
float tempFAverage = 0;


// TEMPERATURE FUNCTIONS
void swDelay(char numLoops1);
void swDelay2(char numLoops);
int ledDecimal(int binaryInput);
void displayTime(long unsigned int inTime);

#define CALADC12_15V_30C  *((unsigned int *)0x1A1A)
#define CALADC12_15V_85C  *((unsigned int *)0x1A1C)
#define MA_PER_BIT 0.244  // =1.0A/4096
#define CALADC12_25V_30C  *((unsigned int *)0x1A22)
#define CALADC12_25V_85C  *((unsigned int *)0x1A24)

void displayTemp(float inAvgTempC, float inAvgTempF, long unsigned int inTime);
void displayOnLCD(unsigned char monthDay[9],  unsigned char hourMinSec[9],  unsigned char tempCAverage[9],  unsigned char tempFAverage[9], long unsigned int inTime);
void tempExample(long unsigned int inTime);
void ftoa(float n, char* res, int afterpoint);

char strC[35];
char strF[35];
int modulo30;
unsigned char strTEMPC[35];
unsigned char strTEMPF[35];
unsigned int   in_current,in_temp;
float  milliamps, tempC, tempF;
float arrayIndex = 1;
unsigned int inValue = 0;

// SCROLL WHEEL
void scrollWheelMonth(float inputReading, long unsigned int inTime);
void scrollWheelDay(float inputReading, long unsigned int inTime);
void scrollWheelHour(float inputReading, long unsigned int inTime);
void scrollWheelMinute(float inputReading, long unsigned int inTime);
void scrollWheelSecond(float inputReading, long unsigned int inTime);

unsigned long int newMonth;
unsigned long int newDay;
unsigned long int newHour;
unsigned long int newMinute;
unsigned long int newSecond;

unsigned long int currentMonth;
unsigned long int currentDay;
unsigned long int currentHour;
unsigned long int currentMinute;
unsigned long int currentSecond;

volatile unsigned long newTimer=0;




#pragma vector=TIMER2_A0_VECTOR
__interrupt void TimerA2_ISR(void)
{
    if(leapCount <1024){ // can go until error cycle reached
        timer++;
        leapCount++;
    } else {            // do the leap count to correct for error
        timer+=2;
        leapCount = 0;
    }

    if ((timer % 50) == 0) { // blinking LED
        P1OUT ^= BIT0;
    }

}


enum GAME_STATE {DISPLAY, EDITmonth, EDITday, EDIThour, EDITminute, EDITsecond}; // display displays and edit for scroll wheel


// Main
void main(void) {

     WDTCTL = WDTPW | WDTHOLD;    // Stop watchdog timer. Always need to stop this!!
                                  // You can then configure it properly, if desired

     // Useful code starts here
     initLeds();
     configDisplay();
     configKeypad();

     // Configure LED P1.0 FOR TIMER
     P1SEL &= ~BIT0;
     P1DIR |= BIT0;
     startingA2Timer();
     _enable_interrupts(); // Enables global interrupts

     enum GAME_STATE state = DISPLAY;


     // for temp
     REFCTL0 &= ~REFMSTR;
     ADC12CTL0=ADC12SHT0_9|ADC12REFON|ADC12REF2_5V|ADC12ON|ADC12MSC;
     ADC12CTL1 = ADC12SHP+ADC12CONSEQ_1;
     ADC12MCTL0 = ADC12SREF_1 + ADC12INCH_0;
     ADC12MCTL1 = ADC12SREF_1 + ADC12INCH_10 + ADC12EOS;
     P6SEL = P6SEL | BIT0;

     while (1) {

         currKey = getKey(); // Get a character from the keypad
         current_time = timer; // for global A2 Timer
         elapsed_time = current_time - start_time;


         switch (state) {

                 case DISPLAY:
                     setLeds(0);
                     Graphics_drawStringCentered(&g_sContext, "      ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
                     Graphics_flushBuffer(&g_sContext); // refresh
                     displayTime(timer); // my function always pulling current time
                     Graphics_flushBuffer(&g_sContext);
                     tempExample(timer);
                     displayTemp(tempC, tempF, timer);

                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITmonth;
                     }

                 break;

                 case EDITmonth:
                     Graphics_drawStringCentered(&g_sContext, "  MONTH  ", AUTO_STRING_LENGTH, 50, 15, OPAQUE_TEXT);
                     Graphics_flushBuffer(&g_sContext); // refresh

                     tempExample(timer);
                     scrollWheelMonth(milliamps, timer);


                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITday;
                     }
                     if(currKey == '2'){
                         Graphics_flushBuffer(&g_sContext);
                         state = DISPLAY;
                     }

                 break;

                 case EDITday:
                     Graphics_drawStringCentered(&g_sContext, "  DAY  ", AUTO_STRING_LENGTH, 50, 15, OPAQUE_TEXT);
                     Graphics_flushBuffer(&g_sContext); // refresh

                     tempExample(timer);
                     scrollWheelDay(milliamps, timer);


                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDIThour;
                     }
                     if(currKey == '2'){
                         Graphics_flushBuffer(&g_sContext);
                         state = DISPLAY;
                     }

                 break;

                 case EDIThour:
                     Graphics_drawStringCentered(&g_sContext, "  HOUR  ", AUTO_STRING_LENGTH, 50, 15, OPAQUE_TEXT);
                     Graphics_flushBuffer(&g_sContext); // refresh

                     tempExample(timer);
                     scrollWheelHour(milliamps, timer);


                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITminute;
                     }
                     if(currKey == '2'){
                         Graphics_flushBuffer(&g_sContext);
                         state = DISPLAY;
                     }

                 break;


                 case EDITminute:
                     Graphics_drawStringCentered(&g_sContext, "MINUTE", AUTO_STRING_LENGTH, 50, 15, OPAQUE_TEXT);
                     Graphics_flushBuffer(&g_sContext); // refresh

                     tempExample(timer);
                     scrollWheelMinute(milliamps, timer);


                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITsecond;
                     }
                      if(currKey == '2'){
                          Graphics_flushBuffer(&g_sContext);
                          state = DISPLAY;
                      }

                  break;

                 case EDITsecond:
                     Graphics_drawStringCentered(&g_sContext, "SECOND", AUTO_STRING_LENGTH, 50, 15, OPAQUE_TEXT);
                     Graphics_flushBuffer(&g_sContext); // refresh

                     tempExample(timer);
                     scrollWheelSecond(milliamps, timer);


                     if(currKey == '1'){ // first switch to edit mode
                         Graphics_flushBuffer(&g_sContext);
                         state = EDITmonth;
                     }
                      if(currKey == '2'){
                          Graphics_flushBuffer(&g_sContext);
                          state = DISPLAY;
                      }

                  break;



             } // end of states


     } // end of while(1)

}



// FUNCTIONS START HERE


void swDelay(char numLoops1)
{

	volatile unsigned int i,j;	// volatile to prevent removal in optimization
			                    // by compiler. Functionally this is useless code

	for (j=0; j<numLoops1; j++)
    {
    	i = 50000 ;					// SW Delay
   	    while (i > 0)				// could also have used while (i)
	       i--;
    }
}



void swDelay2(char numLoops)
{
    volatile unsigned int i,j;  // volatile to prevent removal in optimization
                                // by compiler. Functionally this is useless code
    for (j=0; j<numLoops; j++)
    {
        i = 50000 ;                 // SW Delay
        while (i > 0)               // could also have used while (i)
           i--;
    }
}

int ledDecimal(int binaryInput){
    if (binaryInput == 1) {
        return 8;
    }
    if (binaryInput == 2){
        return 4;
    }
    if (binaryInput == 3){
        return 2;
    }
    if (binaryInput == 4){
        return 1;
    } return 0;
}

// A2 TIMER FUNCTIONS

void startingA2Timer(void){
    TA2CTL = TASSEL_1 | ID_0 | MC_1; // ACLK, Divide by 1, Up mode
    TA2CCR0 = 327;                   // 327 + 1 ACLK ticks = 0.01s
    TA2CCTL0 = CCIE;                 // Enable capture/compare interrupt
}
void stoppingA2Timer(void){
    TA2CTL = MC_0;     // Stop mode
    TA2CCTL0 &= ~CCIE; // Disable interrupts
}


void timerA2Function(){
    timer_on = 0; // for A2 timer
    start_time = 0; // for A2 timer
    currKey = getKey();
    if (currKey == '1') {
        timer_on = 1;
        start_time = timer; // Record timer value at start
    }
    if (currKey == '2') {
        timer_on = 0;
    }
    if (timer_on) {
        current_time = timer;
        elapsed_time = current_time - start_time;
        if ((timer % 10) == 0) {
            //displayingA2Timer(elapsed_time);
            Graphics_flushBuffer(&g_sContext);
        }
    }
}


void displayTime(long unsigned int inTime){ // needs to be always running in main while(1) loop
    // pass in global timer variable for parameter

    month = inTime/(259200000);
    monthMod = month % 12;
    day = inTime/(8640000);
    dayMod = day % 30;
    hour = inTime/(360000);
    hourMod = hour % 24;
    minute = inTime/(6000);
    minuteMod = minute % 60;
    second  = inTime/100;
    secondMod = second % 60;
    count = secondMod % 12;

    usnprintf(strDATE, 9, " %s %s   ", monthCurrent[monthMod], dayCurrent[dayMod]);
    usnprintf(strTIME, 9, "%02d:%02d:%02d", hourMod, minuteMod, secondMod);


    if ((count>=0) && (count <=2)){
        Graphics_flushBuffer(&g_sContext);
        Graphics_drawStringCentered(&g_sContext, strDATE, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }
    if ((count>=3) && (count <=5)) {
        Graphics_flushBuffer(&g_sContext);
        Graphics_drawStringCentered(&g_sContext, strTIME, 9, 48, 15, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext);
    }

    printf("month %d, day %d, hour %d, minute %d, second %d, count %d\n", monthMod, dayMod, hourMod, minuteMod, secondMod, count);

}

void tempExample(long unsigned int inTime) {
    ADC12CTL0   &= ~ ADC12SC ;
    ADC12CTL0   |= ADC12SC + ADC12ENC;
    while (ADC12CTL1 & ADC12BUSY)   // poll busy    bit
        //__no_operation();
    in_current = ADC12MEM0 & 0x0FFF;    // keep only low 12 bits
    in_temp = ADC12MEM1 & 0x0FFF;   // keep only low 12 bits
    milliamps = (float)in_current * MA_PER_BIT;
    tempC = (float)(((long)in_temp  - CALADC12_25V_30C)*    (85  - 30))/(CALADC12_25V_85C   - CALADC12_25V_30C) + 30.0;
    tempF = (tempC * 9/5)+32;
    //printf("%f C\n", tempC);
    //printf("%f F\n", tempF);
    //printf("mili %f \n", milliamps);

}

void displayTemp(float inAvgTempC, float inAvgTempF, long unsigned int inTime){


    // for display purposes
    second  = inTime/100;
    secondMod = second % 60;
    count = secondMod % 12;

    newCounter = secondMod % 35; // holding thirty five indexes

    if((count>=6) && (count<7) ){
        if(counterMOD == 0){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 1;
        }
    }
    if((count>=7) && (count<8) ){
        if(counterMOD == 1){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);

            counterMOD = 2;
        }
    }
    if((count>=8) && (count<9) ){
        if(counterMOD == 2){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPC, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 3;
        }
    }
    if((count>=9) && (count<10) ){
        if(counterMOD == 3){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 4;
        }
    }
    if((count>=10) && (count<11) ){
        if(counterMOD == 4){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 5;
        }
    }
    if((count>=11) && (count<12) ){
        if(counterMOD == 5){
            strTEMPC[newCounter] = inAvgTempC; // storing the temperatures into an array that holds thirty values
            strTEMPF[newCounter] = inAvgTempF;

            tempCAverage = 0; // resetting value for each function loop cycle
            tempFAverage = 0;
            for (i = 0; i <35; i++){
                tempCAverage = strTEMPC[newCounter] + tempCAverage;
                tempFAverage = strTEMPF[newCounter] + tempFAverage;
            }

            sprintf(strC, "%.1f", tempCAverage/35);//make the number into string using sprintf function
            sprintf(strF, "%.1f", tempFAverage/35);//make the number into string using sprintf function

            usnprintf(strTEMPC, 9, " %s C ", strC);
            usnprintf(strTEMPF, 9, " %s F ", strF);

            Graphics_drawStringCentered(&g_sContext, strTEMPF, 9, 48, 15, OPAQUE_TEXT);
            Graphics_flushBuffer(&g_sContext);
            counterMOD = 0;
        }
    }

}

// SCROLL WHEEL (miliamp and timer parameters)

void scrollWheelMonth(float inputReading, long unsigned int inTime){

    if((inputReading >= 0) && ((inputReading < 83.25))) {
        newMonth = 0;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "JAN", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 83.25) && ((inputReading < 166.5))) {
        newMonth = 259200000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "FEB", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 166.5) && ((inputReading < 249.75))) {
        newMonth = 518400000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "MAR", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 249.75) && ((inputReading < 333))) {
        newMonth = 777600000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "APR", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 333) && ((inputReading < 390))) {
        newMonth = 1036800000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "MAY", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 390) && ((inputReading < 416.25))) {
        newMonth = 1296000000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "JUN", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 416.25) && ((inputReading < 499.5))) {
        newMonth = 1296000000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "JUL", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 499.5) && ((inputReading < 582.75))) {
        newMonth = 1555200000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "AUG", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 582.75) && ((inputReading < 666))) {
        newMonth = 1814400000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "SEP", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 666) && ((inputReading < 749.25))) {
        newMonth = 2073600000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "OCT", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 749.25) && ((inputReading < 832.5))) {
        newMonth = 2332800000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "NOV", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 832.5) && ((inputReading <= 999))) {
        newMonth = 2592000000;
        timer = newMonth;
        Graphics_drawStringCentered(&g_sContext, "DEC", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
}

void scrollWheelDay(float inputReading, long unsigned int inTime){

    if((inputReading >= 0) && ((inputReading < 33.3))) {
        newDay = 0;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  1  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 33.3) && ((inputReading < 66.6))) {
        newDay = 8640000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  2  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 66.6) && ((inputReading < 99.9))) {
        newDay = 17280000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  3  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 99.9) && ((inputReading < 133.2))) {
        newDay = 25920000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  4  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 133.2) && ((inputReading < 166.5))) {
        newDay = 34560000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  5  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 166.5) && ((inputReading < 199.8))) {
        newDay = 43200000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  6  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 199.8) && ((inputReading < 233.1))) {
        newDay = 51840000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  7  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 233.1) && ((inputReading < 266.4))) {
        newDay = 51840000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  8  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 266.4) && ((inputReading < 299.7))) {
        newDay = 69120000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  9  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 299.7) && ((inputReading < 333))) {
        newDay = 77760000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  10  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 333) && ((inputReading < 366.3))) {
        newDay = 86400000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  11  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 366.3) && ((inputReading < 399.6))) {
        newDay = 95040000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  12  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 399.6) && ((inputReading < 432.9))) {
        newDay = 103680000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  13  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 432.9) && ((inputReading < 466.2))) {
        newDay = 112320000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  14  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 466.2) && ((inputReading < 499.5))) {
        newDay = 120960000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  15  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 499.5) && ((inputReading < 532.8))) {
        newDay = 129600000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  16  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 532.8) && ((inputReading < 566.1))) {
        newDay = 138240000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  17  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 566.1) && ((inputReading < 599.4))) {
        newDay = 146880000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  18  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 599.4) && ((inputReading < 632.7))) {
        newDay = 155520000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  19  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 632.7) && ((inputReading < 666))) {
        newDay = 164160000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  20  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 666) && ((inputReading < 699.3))) {
        newDay = 172800000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  21  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 699.3) && ((inputReading < 732.6))) {
        newDay = 181440000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  22  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 732.6) && ((inputReading < 765.9))) {
        newDay = 190080000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  23  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 765.9) && ((inputReading < 799.2))) {
        newDay = 198720000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  24  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 799.2) && ((inputReading < 832.5))) {
        newDay = 207360000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  25  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 832.5) && ((inputReading < 865.8))) {
        newDay = 216000000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  26  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 865.8) && ((inputReading < 899.1))) {
        newDay = 224640000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  27  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 899.1) && ((inputReading < 932.4))) {
        newDay = 233280000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  28  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 932.4) && ((inputReading < 965.7))) {
        newDay = 241920000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  29  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 965.7) && ((inputReading <= 999))) {
        newDay = 250560000;
        timer = newMonth + newDay;
        Graphics_drawStringCentered(&g_sContext, "  30  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
}

void scrollWheelHour(float inputReading, long unsigned int inTime){

    if((inputReading >= 0) && ((inputReading < 41.625))) {
        newHour = 0;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  1  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 41.625) && ((inputReading < 83.25))) {
        newHour = 360000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  2  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 83.25) && ((inputReading < 124.875))) {
        newHour = 720000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  3  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 124.875) && ((inputReading < 166.5))) {
        newHour = 1080000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  4  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 166.5) && ((inputReading < 208.125))) {
        newHour = 1440000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  5  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 208.125) && ((inputReading < 249.75))) {
        newHour = 1800000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  6  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 249.75) && ((inputReading < 291.375))) {
        newHour = 2160000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  7  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 291.375) && ((inputReading < 333))) {
        newHour = 2520000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  8  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 333) && ((inputReading < 374.625))) {
        newHour = 2880000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  9  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 374.625) && ((inputReading < 416.25))) {
        newHour = 3240000;        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  10  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 416.25) && ((inputReading < 457.875))) {
        newHour = 3600000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  11  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 457.875) && ((inputReading < 499.5))) {
        newHour = 3960000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  12  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 499.5) && ((inputReading < 541.125))) {
        newHour = 4320000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  13  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 541.125) && ((inputReading < 582.75))) {
        newHour = 4680000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  14  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 582.75) && ((inputReading < 624.375))) {
        newHour = 5040000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  15  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 624.375) && ((inputReading < 666))) {
        newHour = 5400000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  16  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 666) && ((inputReading < 707.625))) {
        newHour = 5760000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  17  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 707.625) && ((inputReading < 749.25))) {
        newHour = 6120000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  18  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 749.25) && ((inputReading < 790.875))) {
        newHour = 6480000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  19  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 790.875) && ((inputReading < 832.5))) {
        newHour = 6840000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  20  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 832.5) && ((inputReading < 874.125))) {
        newHour = 7200000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  21  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 874.125) && ((inputReading < 915.75))) {
        newHour = 7560000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  22  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 915.75) && ((inputReading < 957.375))) {
        newHour = 7920000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  23  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 957.375) && ((inputReading <= 999))) {
        newHour = 8280000;
        timer = newMonth + newDay + newHour;
        Graphics_drawStringCentered(&g_sContext, "  24  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
}

void scrollWheelMinute(float inputReading, long unsigned int inTime){

    if((inputReading >= 0) && ((inputReading < 16.65))) {
        newMinute = 0;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  1  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 16.65) && ((inputReading < 33.3))) {
        newMinute = 6000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  2  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 33.3) && ((inputReading < 49.95))) {
        newMinute = 12000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  3  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 49.95) && ((inputReading < 66.6))) {
        newMinute = 18000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  4  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 66.6) && ((inputReading < 83.25))) {
        newMinute = 24000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  5  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 83.25) && ((inputReading < 99.9))) {
        newMinute = 30000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  6  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 99.9) && ((inputReading < 116.55))) {
        newMinute = 36000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  7  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 116.55) && ((inputReading < 133.2))) {
        newMinute = 42000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  8  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 133.2) && ((inputReading < 149.85))) {
        newMinute = 48000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  9  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 149.85) && ((inputReading < 166.5))) {
        newMinute = 54000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  10  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 166.5) && ((inputReading < 183.15))) {
        newMinute = 60000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  11  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 183.15) && ((inputReading < 199.8))) {
        newMinute = 66000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  12  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 199.8) && ((inputReading < 216.45))) {
        newMinute = 72000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  13  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 216.45) && ((inputReading < 233.1))) {
        newMinute = 78000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  14  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 233.1) && ((inputReading < 249.75))) {
        newMinute = 84000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  15  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 249.75) && ((inputReading < 266.4))) {
        newMinute = 90000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  16  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 266.4) && ((inputReading < 283.05))) {
        newMinute = 96000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  17  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 283.05) && ((inputReading < 299.7))) {
        newMinute = 102000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  18  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 299.7) && ((inputReading < 316.35))) {
        newMinute = 108000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  19  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 316.35) && ((inputReading < 333))) {
        newMinute = 114000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  20  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 333) && ((inputReading < 349.65))) {
        newMinute = 120000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  21  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 349.65) && ((inputReading < 366.3))) {
        newMinute = 126000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  22  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 366.3) && ((inputReading < 382.95))) {
        newMinute = 132000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  23  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 382.95) && ((inputReading < 399.6))) {
        newMinute = 138000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  24  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 399.6) && ((inputReading < 416.25))) {
        newMinute = 144000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  25  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 416.25) && ((inputReading < 432.9))) {
        newMinute = 150000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  26  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 432.9) && ((inputReading < 449.55))) {
        newMinute = 156000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  27  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 449.55) && ((inputReading < 466.2))) {
        newMinute = 162000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  28  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 466.2) && ((inputReading < 482.85))) {
        newMinute = 168000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  29  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 482.85) && ((inputReading < 499.5))) {
        newMinute = 174000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  30  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 499.5) && ((inputReading < 516.15))) {
        newMinute = 180000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  31  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 516.15) && ((inputReading < 532.8))) {
        newMinute = 186000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  32  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 532.8) && ((inputReading < 549.45))) {
        newMinute = 192000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  33  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 549.45) && ((inputReading < 566.1))) {
        newMinute = 198000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  34  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 566.1) && ((inputReading < 582.75))) {
        newMinute = 204000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  35  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 582.75) && ((inputReading < 599.4))) {
        newMinute = 210000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  36  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 599.4) && ((inputReading < 616.05))) {
        newMinute = 216000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  37  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 616.05) && ((inputReading < 632.7))) {
        newMinute = 222000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  38  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 632.7) && ((inputReading < 649.35))) {
        newMinute = 228000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  39  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 649.35) && ((inputReading < 666))) {
        newMinute = 234000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  40  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 666) && ((inputReading < 682.65))) {
        newMinute = 240000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  41  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 682.65) && ((inputReading < 699.3))) {
        newMinute = 246000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  42  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 699.3) && ((inputReading < 715.95))) {
        newMinute = 252000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  43  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 715.95) && ((inputReading < 732.6))) {
        newMinute = 258000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  44  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 732.6) && ((inputReading < 749.25))) {
        newMinute = 264000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  45  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 749.25) && ((inputReading < 765.9))) {
        newMinute = 270000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  46  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 765.9) && ((inputReading < 782.55))) {
        newMinute = 276000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  47  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 782.55) && ((inputReading < 799.2))) {
        newMinute = 282000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  48  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 799.2) && ((inputReading < 815.85))) {
        newMinute = 286000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  49  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 815.85) && ((inputReading < 832.5))) {
        newMinute = 294000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  50  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 832.5) && ((inputReading < 849.15))) {
        newMinute = 300000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  51  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 849.15) && ((inputReading < 865.8))) {
        newMinute = 306000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  52  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 865.8) && ((inputReading < 882.45))) {
        newMinute = 312000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  53  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 882.45) && ((inputReading < 899.1))) {
        newMinute = 318000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  54  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 899.1) && ((inputReading < 915.75))) {
        newMinute = 324000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  55  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 915.75) && ((inputReading < 932.4))) {
        newMinute = 330000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  56  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 932.4) && ((inputReading < 949.05))) {
        newMinute = 336000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  57  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 949.05) && ((inputReading < 965.7))) {
        newMinute = 342000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  58  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 965.7) && ((inputReading < 982.35))) {
        newMinute = 348000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  59  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 982.35) && ((inputReading <= 999))) {
        newMinute = 364000;
        timer = newMonth + newDay + newHour + newMinute;
        Graphics_drawStringCentered(&g_sContext, "  60  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
}

void scrollWheelSecond(float inputReading, long unsigned int inTime){

    if((inputReading >= 0) && ((inputReading < 16.65))) {
        newSecond = 0;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  1  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 16.65) && ((inputReading < 33.3))) {
        newSecond = 100;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  2  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 33.3) && ((inputReading < 49.95))) {
        newSecond = 200;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  3  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 49.95) && ((inputReading < 66.6))) {
        newSecond = 300;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  4  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 66.6) && ((inputReading < 83.25))) {
        newSecond = 400;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  5  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 83.25) && ((inputReading < 99.9))) {
        newSecond = 500;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  6  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 99.9) && ((inputReading < 116.55))) {
        newSecond = 600;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  7  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 116.55) && ((inputReading < 133.2))) {
        newSecond = 700;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  8  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 133.2) && ((inputReading < 149.85))) {
        newSecond = 800;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  9  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 149.85) && ((inputReading < 166.5))) {
        newSecond = 900;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  10  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 166.5) && ((inputReading < 183.15))) {
        newSecond = 1000;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  11  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 183.15) && ((inputReading < 199.8))) {
        newSecond = 1100;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  12  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 199.8) && ((inputReading < 216.45))) {
        newSecond = 1200;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  13  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 216.45) && ((inputReading < 233.1))) {
        newSecond = 1300;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  14  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 233.1) && ((inputReading < 249.75))) {
        newSecond = 1400;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  15  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 249.75) && ((inputReading < 266.4))) {
        newSecond = 1500;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  16  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 266.4) && ((inputReading < 283.05))) {
        newSecond = 1600;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  17  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 283.05) && ((inputReading < 299.7))) {
        newSecond = 1700;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  18  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 299.7) && ((inputReading < 316.35))) {
        newSecond = 1800;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  19  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 316.35) && ((inputReading < 333))) {
        newSecond = 1900;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  20  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 333) && ((inputReading < 349.65))) {
        newSecond = 2000;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  21  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 349.65) && ((inputReading < 366.3))) {
        newSecond = 2100;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  22  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 366.3) && ((inputReading < 382.95))) {
        newSecond = 2200;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  23  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 382.95) && ((inputReading < 399.6))) {
        newSecond = 2300;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  24  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 399.6) && ((inputReading < 416.25))) {
        newSecond = 2400;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  25  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 416.25) && ((inputReading < 432.9))) {
        newSecond = 2500;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  26  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 432.9) && ((inputReading < 449.55))) {
        newSecond = 2600;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  27  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 449.55) && ((inputReading < 466.2))) {
        newSecond = 2700;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  28  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 466.2) && ((inputReading < 482.85))) {
        newSecond = 2800;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  29  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 482.85) && ((inputReading < 499.5))) {
        newSecond = 2900;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  30  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 499.5) && ((inputReading < 516.15))) {
        newSecond = 3000;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  31  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 516.15) && ((inputReading < 532.8))) {
        newSecond = 3100;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  32  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 532.8) && ((inputReading < 549.45))) {
        newSecond = 3200;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  33  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 549.45) && ((inputReading < 566.1))) {
        newSecond = 3300;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  34  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 566.1) && ((inputReading < 582.75))) {
        newSecond = 3400;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  35  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 582.75) && ((inputReading < 599.4))) {
        newSecond = 3500;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  36  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 599.4) && ((inputReading < 616.05))) {
        newSecond = 3600;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  37  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 616.05) && ((inputReading < 632.7))) {
        newSecond = 3700;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  38  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 632.7) && ((inputReading < 649.35))) {
        newSecond = 3800;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  39  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 649.35) && ((inputReading < 666))) {
        newSecond = 3900;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  40  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 666) && ((inputReading < 682.65))) {
        newSecond = 4000;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  41  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 682.65) && ((inputReading < 699.3))) {
        newSecond = 4100;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  42  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 699.3) && ((inputReading < 715.95))) {
        newSecond = 4200;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  43  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 715.95) && ((inputReading < 732.6))) {
        newSecond = 4300;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  44  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 732.6) && ((inputReading < 749.25))) {
        newSecond = 4400;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  45  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 749.25) && ((inputReading < 765.9))) {
        newSecond = 4500;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  46  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 765.9) && ((inputReading < 782.55))) {
        newSecond = 4600;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  47  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 782.55) && ((inputReading < 799.2))) {
        newSecond = 4700;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  48  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 799.2) && ((inputReading < 815.85))) {
        newSecond = 4800;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  49  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 815.85) && ((inputReading < 832.5))) {
        newSecond = 4900;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  50  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 832.5) && ((inputReading < 849.15))) {
        newSecond = 500;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  51  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 849.15) && ((inputReading < 865.8))) {
        newSecond = 5100;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  52  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 865.8) && ((inputReading < 882.45))) {
        newSecond = 5200;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  53  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 882.45) && ((inputReading < 899.1))) {
        newSecond = 5300;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  54  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 899.1) && ((inputReading < 915.75))) {
        newSecond = 5400;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  55  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 915.75) && ((inputReading < 932.4))) {
        newSecond = 5500;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  56  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
    if((inputReading >= 932.4) && ((inputReading < 949.05))) {
        newSecond = 5600;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  57  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('8' - 0x30);
    }
    if((inputReading >= 949.05) && ((inputReading < 965.7))) {
        newSecond = 5700;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  58  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('4' - 0x30);
    }
    if((inputReading >= 965.7) && ((inputReading < 982.35))) {
        newSecond = 5800;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  59  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('2' - 0x30);
    }
    if((inputReading >= 982.35) && ((inputReading <= 999))) {
        newSecond = 5900;
        timer = newMonth + newDay + newHour + newMinute + newSecond;
        Graphics_drawStringCentered(&g_sContext, "  60  ", AUTO_STRING_LENGTH, 50, 45, OPAQUE_TEXT);
        Graphics_flushBuffer(&g_sContext); // refresh
        setLeds('1' - 0x30);
    }
}





